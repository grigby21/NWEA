/// <reference types="cypress" />

describe('Verify Instagram.com Homepage', ()=>{
   beforeEach(()=>{

   })
it('Verify Instagram page appears',()=>{
    cy.visit('http://www.instagram.com')
    cy.get('h1')
        .contains('Instagram')
 })

it('Verify Sign up appears',()=>{
    cy.visit('http://www.instagram.com')
    cy.contains('Don\'t have an account? Sign up')
})

it('Verify Forgot password appears',()=>{
    cy.visit('http://www.instagram.com')
    cy.contains('Forgot password?')
})

it('Verify Footer links',()=>{
         cy.visit('http://www.instagram.com')
    cy.contains('Meta'),
    cy.contains('About'),
    cy.contains('Blog'),
    cy.contains('Jobs'),
    cy.contains('Help'),
    cy.contains('API'),
    cy.contains('Privacy'),
    cy.contains('Terms'),
    cy.contains('Top Accounts'),
    cy.contains('Hashtags'),
    cy.contains('Locations'),
    cy.contains('Instagram Lite'),
    cy.contains('Dance'),
    cy.contains('Food & Drink'),
    cy.contains('Home & Garden'),
    cy.contains('Music'),
    cy.contains('Visual Arts'),
    cy.contains('© 2022 Instagram from Meta')
  
})


it('Verify Username appears',()=>{
    cy.visit('http://www.instagram.com')
    cy.get('[name ="username"]').should('have.attr', 'aria-label', 'Phone number, username, or email')
})

it('Verify Password appears',()=>{
    cy.visit('http://www.instagram.com')
    cy.get('[name ="password"]').should('have.attr', 'aria-label', 'Password')
})

it('Verify App Store images appears',()=>{
    cy.visit('http://www.instagram.com')
    cy.get('[alt ="Download on the App Store"]').should('have.attr', 'src', '/static/images/appstore-install-badges/badge_ios_english-en.png/180ae7a0bcf7.png'),
    cy.get('[alt ="Get it on Google Play"]').should('have.attr', 'src', '/static/images/appstore-install-badges/badge_android_english-en.png/e9cd846dc748.png')
})

})