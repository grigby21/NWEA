var data = [[1,2],3,4,[5,[6,7],["a"],["b","c"],["d"]]];

function flattenArray(varArray) {
    let flatArray = []; 

    varArray.forEach(element => {
        if (Array.isArray(element)){
            flatArray = flatArray.concat(flattenArray(element));
        }
        else{
            flatArray.push(element);
        }
    })

    return flatArray;

}

const flattenedArrayList = flattenArray(data);

console.log(flattenedArrayList);

